"""
Small helpers (logging, safe file IO)
"""
import json
from pathlib import Path

def save_json_restrict(path: Path, data):
    path.write_text(json.dumps(data, indent=2))
    try:
        path.chmod(0o600)
    except Exception:
        pass