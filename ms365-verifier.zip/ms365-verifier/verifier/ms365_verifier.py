"""
Playwright-based MS365 verifier with improved request capture and page-context API calls.

- Attaches request handler to the browser context so iframe requests are observed.
- Logs matching checkout API requests (url, method, header keys).
- Saves tokens.json automatically when tokens are captured (safe perms attempted).
- Includes send_verification_from_page to call the API from browser context (avoids CSRF timeouts).
"""
import time
import asyncio
import json
from dataclasses import dataclass
from typing import Optional, Dict, Set
from pathlib import Path

# Constants
MS365_CHECKOUT_URL = "https://checkout.microsoft365.com/acquire/purchase"
MS365_API_BASE = "https://checkout.microsoft365.com/api"

CHECKOUT_PARAMS = {
    "language": "en-US",
    "market": "US",
    "requestedDuration": "Month",
    "scenario": "microsoft-365-student",
    "client": "poc",
    "campaign": "StudentFree12M",
}


@dataclass
class CapturedTokens:
    bearer: str
    x_auth: str
    cookies: str
    timestamp: float

    @property
    def is_valid(self) -> bool:
        return time.time() - self.timestamp < 3600

    def to_headers(self) -> Dict[str, str]:
        return {
            "Authorization": self.bearer,
            "X-Auth": self.x_auth,
            "Cookie": self.cookies,
            "Content-Type": "application/json",
            "Accept": "application/json",
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
        }


class MS365Verifier:
    def __init__(self, headless: bool = False):
        self.headless = headless
        self.playwright = None
        self.browser = None
        self.context = None
        self.page = None
        self.tokens: Optional[CapturedTokens] = None

        # shutdown coordination
        self._close_event = asyncio.Event()
        self._bg_tasks: Set[asyncio.Task] = set()
        self._lock = asyncio.Lock()

    async def launch_browser(self):
        try:
            from playwright.async_api import async_playwright
        except ImportError as e:
            raise RuntimeError(
                "Playwright not installed. Install with: pip install playwright && python -m playwright install chromium"
            ) from e

        # optional stealth
        try:
            from playwright_stealth import stealth_async  # type: ignore
            _has_stealth = True
        except Exception:
            _has_stealth = False

        self.playwright = await async_playwright().start()
        self.browser = await self.playwright.chromium.launch(
            headless=self.headless,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-dev-shm-usage",
                "--no-sandbox",
                "--disable-infobars",
            ],
        )

        self.context = await self.browser.new_context(
            viewport={"width": 1920, "height": 1080},
            user_agent="Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36",
            locale="en-US",
            timezone_id="America/New_York",
            color_scheme="light",
        )

        self.page = await self.context.new_page()

        if _has_stealth:
            try:
                await stealth_async(self.page)  # type: ignore
                print("[INFO] Stealth patches applied")
            except Exception:
                print("[WARN] stealth application failed")

        # page/context close handlers
        self.page.on("close", lambda: asyncio.create_task(self._on_page_close()))
        self.context.on("close", lambda: asyncio.create_task(self._on_context_close()))

        # Attach request handler at context level so iframe requests are also seen
        def _on_request_wrapper(req):
            task = asyncio.create_task(self._on_request(req))
            self._register_task(task)

        self.context.on("request", _on_request_wrapper)

        print("[INFO] Browser launched successfully")

    def _register_task(self, task: asyncio.Task):
        self._bg_tasks.add(task)

        def _on_done(_t):
            self._bg_tasks.discard(task)

        task.add_done_callback(_on_done)

    async def _on_request(self, request):
        """Capture / debug checkout API requests across context (frames included)."""
        try:
            url = request.url
            method = request.method
            # Only inspect checkout.microsoft365.com API requests (tunable)
            if "checkout.microsoft365.com" not in url or "/api/" not in url:
                return

            # Debug logging — show method, short URL and header keys
            headers = {k.lower(): v for k, v in request.headers.items()}
            auth_present = bool(headers.get("authorization"))
            x_auth_present = bool(headers.get("x-auth"))
            print(f"[DEBUG] {method} {url}")
            print(f"[DEBUG] header keys: {list(headers.keys())}")
            print(f"[DEBUG] authorization_present={auth_present} x-auth_present={x_auth_present}")

            # Attempt to capture tokens if present
            bearer = headers.get("authorization", "") or ""
            x_auth = headers.get("x-auth", "") or ""
            if not bearer and not x_auth:
                # no tokens in this request
                return

            # get cookies for the current context
            cookies_str = ""
            try:
                cookies_list = await self.context.cookies()
                cookies_str = "; ".join([f"{c['name']}={c['value']}" for c in cookies_list])
            except Exception:
                cookies_str = ""

            if bearer and not bearer.lower().startswith("bearer "):
                bearer = f"Bearer {bearer}"

            self.tokens = CapturedTokens(
                bearer=bearer,
                x_auth=x_auth,
                cookies=cookies_str,
                timestamp=time.time(),
            )

            # Save tokens immediately
            self._save_tokens_file()

            print(f"[INFO] Tokens captured at {time.strftime('%H:%M:%S')}")
        except asyncio.CancelledError:
            raise
        except Exception as e:
            print(f"[WARN] request handler error: {e}")

    def _save_tokens_file(self):
        try:
            root = Path(__file__).resolve().parent.parent
            tokens_file = root / "tokens.json"
            content = {
                "bearer": self.tokens.bearer,
                "x_auth": self.tokens.x_auth,
                "cookies": self.tokens.cookies,
                "timestamp": self.tokens.timestamp,
            }
            tokens_file.write_text(json.dumps(content, indent=2))
            try:
                tokens_file.chmod(0o600)
            except Exception:
                pass
        except Exception as e:
            print(f"[WARN] failed to save tokens.json: {e}")

    async def navigate_to_checkout(self) -> bool:
        """Open the MS checkout page (and wait for potential interactive sign-in)."""
        from urllib.parse import urlencode

        params = urlencode(CHECKOUT_PARAMS)
        url = f"{MS365_CHECKOUT_URL}?{params}"
        print(f"[INFO] Navigating to checkout: {url}")

        try:
            await self.page.goto(url, wait_until="load", timeout=60000)
        except Exception as e:
            print(f"[ERROR] Navigation failed: {repr(e)}")
            return False

        # handle interactive login if needed
        if "login.microsoftonline.com" in self.page.url or "login.live.com" in self.page.url:
            print("[INFO] Sign-in required. Please complete sign-in in the opened browser window.")
            start = time.time()
            while time.time() - start < 300:  # 5 minutes
                try:
                    cur_url = self.page.url
                except Exception:
                    cur_url = ""
                if "checkout.microsoft365.com" in cur_url:
                    break
                await asyncio.sleep(1)
            else:
                print("[ERROR] Timeout waiting for sign-in to complete")
                return False
            print("[INFO] Sign-in completed; back on checkout domain.")

        return True

    async def wait_for_tokens(self, timeout: int = 30) -> bool:
        print("[INFO] Waiting for authentication tokens...")
        start = time.time()
        while time.time() - start < timeout:
            if self.tokens and self.tokens.is_valid:
                return True
            await asyncio.sleep(0.5)
        print("[WARN] Token capture timeout")
        return False

    async def _on_page_close(self):
        if not self._close_event.is_set():
            print("[INFO] Detected page close — initiating shutdown")
            self._close_event.set()

    async def _on_context_close(self):
        if not self._close_event.is_set():
            print("[INFO] Detected context close — initiating shutdown")
            self._close_event.set()

    async def wait_for_browser_close(self, timeout: Optional[float] = None) -> bool:
        try:
            if timeout is None:
                await self._close_event.wait()
                return True
            else:
                await asyncio.wait_for(self._close_event.wait(), timeout=timeout)
                return True
        except asyncio.TimeoutError:
            return False

    def verify_student_email(self, email: str) -> Dict:
        import httpx

        if not self.tokens or not self.tokens.is_valid:
            return {"success": False, "error": "No valid tokens"}

        endpoint = f"{MS365_API_BASE}/verifystudent/sendemail"
        payload = {"email": email, "locale": "en-US"}

        try:
            with httpx.Client(timeout=30) as client:
                resp = client.post(endpoint, json=payload, headers=self.tokens.to_headers())
                if resp.status_code == 200:
                    return {"success": True, "data": resp.json()}
                else:
                    return {"success": False, "error": f"HTTP {resp.status_code}", "body": resp.text}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def send_verification_from_page(self, email: str) -> Dict:
        """
        Call the verifystudent/sendemail endpoint from the page context using fetch.
        This avoids CSRF / origin timeouts because the request is made from the browser.
        """
        if not self.page:
            return {"success": False, "error": "No page loaded"}

        script = """
        async (email) => {
          const url = '/api/verifystudent/sendemail';
          try {
            const resp = await fetch(url, {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
              },
              credentials: 'include',
              body: JSON.stringify({ email: email, locale: 'en-US' })
            });
            const txt = await resp.text();
            let json;
            try { json = JSON.parse(txt); } catch(e) { json = txt; }
            return { status: resp.status, body: json };
          } catch (err) {
            return { error: String(err) };
          }
        }
        """
        try:
            result = await self.page.evaluate(script, email)
            print(f"[INFO] Page-context API call result: {result}")
            if result.get("error"):
                return {"success": False, "error": result["error"]}
            else:
                return {"success": True, "status": result["status"], "body": result["body"]}
        except Exception as e:
            return {"success": False, "error": str(e)}

    async def close(self, timeout: float = 10.0):
        async with self._lock:
            if not self._close_event.is_set():
                self._close_event.set()

            if self._bg_tasks:
                print(f"[INFO] Cancelling {len(self._bg_tasks)} background task(s)...")
                for t in list(self._bg_tasks):
                    t.cancel()
                try:
                    await asyncio.wait_for(asyncio.gather(*self._bg_tasks, return_exceptions=True), timeout=2.0)
                except asyncio.TimeoutError:
                    pass
                finally:
                    self._bg_tasks.clear()

            try:
                if self.page:
                    await self.page.close()
            except Exception:
                pass
            try:
                if self.context:
                    await self.context.close()
            except Exception:
                pass
            try:
                if self.browser:
                    await self.browser.close()
            except Exception:
                pass
            try:
                if self.playwright:
                    await self.playwright.stop()
            except Exception:
                pass

            print("[INFO] Shutdown complete")