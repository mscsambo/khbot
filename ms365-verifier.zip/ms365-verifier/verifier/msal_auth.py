"""
Optional: MSAL device-code flow helper — recommended for legitimate token acquisition.
Requires: pip install msal
"""
import msal

def acquire_device_token(client_id: str, tenant: str = "common", scopes=None, timeout: int = 600):
    scopes = scopes or ["https://graph.microsoft.com/.default"]
    app = msal.PublicClientApplication(client_id, authority=f"https://login.microsoftonline.com/{tenant}")
    flow = app.initiate_device_flow(scopes=scopes)
    if "user_code" not in flow:
        raise RuntimeError("device flow start failed")
    print(flow["message"])
    result = app.acquire_token_by_device_flow(flow)  # blocks until finished
    if "access_token" in result:
        return result
    raise RuntimeError(result.get("error_description", str(result)))