"""
Placeholder doc generator. Replace with real generation using Pillow if needed.
Functions return bytes (PNG/JPEG).
"""
def generate_transcript(first: str, last: str, dob: str, school: str) -> bytes:
    # minimal placeholder: return some bytes so upload code can run in tests
    return b"PNG_BYTES_PLACEHOLDER"

def generate_student_id(first: str, last: str, school: str) -> bytes:
    return b"PNG_BYTES_PLACEHOLDER"