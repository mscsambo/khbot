\# MS365 Education Student Verification Tool



Short description and safe-use guidance.



\- Install: `pip install -r requirements.txt`

\- Install Playwright browsers: `playwright install chromium`

\- Run interactive mode: `python main.py`

\- Run direct mode: `python main.py --email student@school.edu --headless`

\- Export tokens (if implemented): `python main.py --export-tokens`



IMPORTANT: Only use this tool with accounts and systems you own or have explicit permission to test.

