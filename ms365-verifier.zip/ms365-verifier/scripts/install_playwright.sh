#!/usr/bin/env bash
python -m pip install -r requirements.txt
python -m playwright install chromium